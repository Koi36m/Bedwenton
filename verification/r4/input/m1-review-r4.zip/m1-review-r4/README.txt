M1 independent review, Amendment 3 / Revision 4 package (Claude Code, 2026-10-15)

NOT PUSHED: GitHub refused the push of branch review/m1-claude (no write access for this session).
Everything below sits on top of m1-core-transforms @ 8397c04b55f7d506e8fec79fca120ce297e8ae22.

review-m1-claude.bundle   git bundle, branch review/m1-claude, prerequisite 8397c04
  git fetch review-m1-claude.bundle review/m1-claude:review/m1-claude
patches/0001-0004          the same 4 commits as git format-patch (git am patches/*.patch on 8397c04)
  da95a353 review, adversarial tests, evidence
  09866629 Amendment 3 proposal and acceptance tests
  f9eefd69 Amendment 3 approved, hint order clarified
  802d9e7f Revision 4 [R4] text applied to the contract
AMENDMENT-3-REVIEW-DECISIONS.md      approved amendment, acceptance criteria for Codex (section 5)
IMPLEMENTATION-CONTRACT-rev4.md      contract with [R4] text
IMPLEMENTATION-CONTRACT-rev3-baseline.md  unchanged Revision 3 contract (sha256 d6d64da9...81f8b3)
revision-4-contract.diff             exact Revision 3 -> Revision 4 contract diff
M1-CLAUDE-REVIEW.md                  review report with addendum

Expected on 8397c04 + this branch, Java 25 + Gradle 9.1.0: 125 tests, 3 failing by design
(D1 x2, A3) until Codex applies the two approved production changes; then 125/125.
